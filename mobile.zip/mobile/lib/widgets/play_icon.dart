  import 'package:flutter/material.dart';

Container playIcon() {
    return Container(
      child: Icon(
        Icons.play_arrow,
        size: 320.0,
      ),
    );
  }