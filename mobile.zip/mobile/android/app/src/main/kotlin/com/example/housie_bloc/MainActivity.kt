package com.example.housie_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
